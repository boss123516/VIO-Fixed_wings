# -*- coding: utf-8 -*-
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,html,zipfile,hashlib
D=Path('/Users/mmmo/Downloads/SCIMITAR_CURA_CAPTURES');R=Path('/Users/mmmo/Adapted-Modular-Scimitar/print_preparation/ENDER3_READY_V2');rows=json.loads((R/'reports/parts.json').read_text());font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24);small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
(D/'thumbnails').mkdir(exist_ok=True);(D/'capture_records').mkdir(exist_ok=True)
for p in D.glob('*.ax.txt'):p.rename(D/'capture_records'/p.name)
canvas=Image.new('RGB',(2400,5*500+100),'#eef2f6');dr=ImageDraw.Draw(canvas);dr.text((30,25),'SCIMITAR  |  19 CURA CAPTURES  |  PLA 18 ready / TPU 015 pending',font=font,fill='#18283b');cards=[];checks=[]
for i,r in enumerate(rows):
 n=r['id'];p=next(D.glob(f'{n:03}_*.png'));im=Image.open(p).convert('RGB');a=np.array(im);mask=(a[:,:,0]>140)&(a[:,:,1]>100)&(a[:,:,2]<130)&(a[:,:,0]>1.2*a[:,:,2])&(a[:,:,1]>1.2*a[:,:,2]);mask[:330]=False;mask[1500:]=False;mask[:,:140]=False;ys,xs=np.where(mask);assert len(xs)>200,(n,len(xs));bb=[max(130,int(xs.min())-150),max(320,int(ys.min())-150),min(im.width,int(xs.max())+150),min(1510,int(ys.max())+150)];crop=im.crop(bb);crop.thumbnail((560,360));tile=Image.new('RGB',(560,360),'#f8f9fa');tile.paste(crop,((560-crop.width)//2,(360-crop.height)//2));tn=f'thumbnails/{n:03}.jpg';tile.save(D/tn,quality=94)
 x=i%4*600+20;y=i//4*500+100;dr.rounded_rectangle((x,y,x+580,y+480),16,fill='white');dr.text((x+15,y+12),f'{n:03}  {r["name"][4:].replace("_"," ")}',font=font,fill='#10253c');canvas.paste(tile,(x+10,y+55));label='TPU: GEOMETRY ONLY' if n==15 else 'PLA: G-code prepared';dr.text((x+15,y+425),label,font=small,fill='#a25b00' if n==15 else '#176459');dr.text((x+15,y+451),' x '.join(f'{v:.1f}' for v in r['plate_box_mm'])+' mm',font=small,fill='#576578')
 title=html.escape(r['name']);status='TPU · 형상 전용 / 출력 설정 미정' if n==15 else 'PLA · 출력 파일 준비';note='시트 1장. 화면의 Generic PLA·20%는 캡처용 빈 프로젝트 기본값이며 TPU 출력 설정이 아닙니다. 형상만 베드 중앙에 표시했습니다.' if n==15 else '판과 잠금 원판을 한 작업에 배치했습니다.' if n==18 else '접착 패드가 포함된 실제 프로젝트입니다.' if n in [8,9] else ''
 cards.append(f'<article data-id="{n:03}"><a class="picture" href="{p.name}" target="_blank"><img src="{tn}" alt="{title} Cura 캡처" loading="lazy"></a><h2>{title}</h2><p class="status {"pending" if n==15 else ""}">{status}</p><p>{" × ".join(f"{v:.1f}" for v in r["plate_box_mm"])} mm</p><p class="note">{note}</p><a href="{p.name}" target="_blank">Cura 원본 캡처 크게 보기 ↗</a></article>')
 checks.append({'id':n,'file':p.name,'resolution':im.size,'geometry_pixels':len(xs),'overview_crop':bb,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
canvas.save(D/'ALL_PARTS_CURA.jpg',quality=94)
(D/'index.html').write_text('''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Scimitar — Cura 부품별 캡처</title><style>body{margin:0;background:#eef2f6;color:#18283b;font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif}header,main{max-width:1500px;margin:auto;padding:30px}h1{font-size:32px;margin-bottom:12px}header p{line-height:1.7;max-width:1050px}nav{display:flex;gap:18px;flex-wrap:wrap}a{color:#185d93}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:22px;padding-top:0}article{background:white;border-radius:14px;padding:18px;box-shadow:0 3px 14px #142b4410}article img{width:100%;height:250px;object-fit:contain;background:#f8f9fa;border-radius:8px}h2{font-size:19px;overflow-wrap:anywhere}.status{color:#176459;font-weight:650}.pending{color:#a25b00}.note{min-height:45px;font-size:14px;line-height:1.5;color:#5d6878}p{font-size:15px}button{padding:8px 16px;border:1px solid #aebdcb;border-radius:8px;background:white;cursor:pointer}footer{padding:30px;text-align:center;color:#687485}</style><header><h1>Scimitar · Cura 부품별 캡처</h1><p>2026-09-26 · 실제 UltiMaker Cura 화면 19장입니다. 아래 축소 이미지는 형상을 찾기 쉽게 원본 캡처의 해당 영역을 잘라 모은 것으로, 그림을 누르면 수정하지 않은 전체 Cura 캡처가 열립니다.</p><p><strong>PLA 18작업은 G-code 준비 완료, TPU 015는 재료 설정 미정.</strong> 실제 출력 시험은 아직입니다. 018에 2개 모델이 있으므로 출력 모델은 총 20개이며, TPU 시트를 6개 힌지로 자르면 조립용 플라스틱 부품은 25개입니다. 캡처는 형상·배치 확인용 PREPARE 화면이며 레이어 검증이나 실제 출력 사진은 아닙니다.</p><nav><a href="ALL_PARTS_CURA.jpg" target="_blank">전체 모음 이미지</a><a href="README_KO.md">설명서</a></nav></header><main>'''+''.join(cards)+'''</main><footer>원본 PNG는 부품 번호 순으로 같은 폴더에 저장되어 있습니다. 모델과 G-code를 이번 캡처 작업에서 변경하지 않았습니다.</footer></html>''')
(D/'README_KO.md').write_text('''# Scimitar Cura 캡처 모음

index.html을 열면 19종을 번호순으로 볼 수 있습니다. 이미지를 누르면 원본 Cura PNG가 열립니다. ALL_PARTS_CURA.jpg는 형상 주변을 잘라 모은 한 장 요약입니다. 원본 PNG는 자르거나 색을 바꾸지 않았습니다.

PLA 18작업은 V2 G-code 준비 완료이며 실제 출력 시험 전입니다. TPU 015는 제품명·경도·권장 온도가 확인되지 않아 형상만 제공합니다. 015 캡처 상단의 Generic PLA / 20%는 빈 Cura 프로젝트의 기본 표시로, TPU 출력 설정이 아닙니다. 힌지 시트는 캡처를 위해 중앙에 표시했으며 원본 형상 파일을 변경하지 않았습니다.

018은 판과 잠금 원판 2개를 한 화면에 담았습니다. 008·009는 제거용 접착 패드도 함께 표시됩니다. 보기 좋은 구도를 위해 카메라만 회전·확대했으며 PLA 프로젝트의 실제 배치·배율·설정·G-code는 변경하지 않았습니다.

19개 원본 출력 파일 / 20개 출력 모델 / 힌지 절단 후 25개 조립 부품입니다. 캡처는 PREPARE의 형상 확인 화면이며 슬라이싱 결과나 물리적 출력 성공 증명은 아닙니다.

capture_records에는 Cura 접근성 상태와 이미지 파일의 검사 기록이 들어 있습니다.
''')
(D/'capture_records/manifest.json').write_text(json.dumps(checks,indent=2));print('Created gallery, overview and',len(checks),'verified original captures')
